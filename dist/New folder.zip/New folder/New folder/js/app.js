$('.headerButton').on('click',function(){
    if ($(window).width() > 768) {
        alert('برای مشاوره و خرید با شماره 26711125 - 021  تماس بگیرید');
     }
     else {
     }

})

